export type UserRole = 'admin' | 'doctor' | 'patient';

export interface User {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  is_approved: boolean;
}

export interface JWTPayload {
  userId: string;
  role: UserRole;
  iat?: number;
  exp?: number;
}

export interface AuthRequest extends Request {
  user?: User;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  role: UserRole;
  specialty?: string;
  bio?: string;
  education?: string[];
  certifications?: string[];
  experienceYears?: number;
  location?: string;
  availability?: string;
  languages?: string[];
}

export interface DoctorProfile {
  id: string;
  user_id: string;
  specialty: string;
  bio: string;
  education: string[];
  certifications: string[];
  experience_years: number;
  avatar_url: string | null;
  location: string;
  availability: string;
  languages: string[];
  rating: number;
  review_count: number;
  username: string;
  email: string;
}

export interface Article {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  author_id: string;
  author_name: string;
  category: string;
  image_url: string;
  read_time: string;
  published_at: string;
  created_at: string;
  updated_at: string;
}

export interface Prescription {
  id: string;
  patient_id: string;
  doctor_id: string;
  symptoms: string;
  diagnosis: string;
  notes: string;
  status: 'active' | 'completed' | 'expired';
  created_at: string;
  updated_at: string;
  valid_until: string;
  patient_name: string;
  doctor_name: string;
  medications: PrescriptionMedication[];
}

export interface PrescriptionMedication {
  id: string;
  prescription_id: string;
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  content: string;
  sender: 'user' | 'ai';
  created_at: string;
  conversation_id: string;
}

export interface APIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
