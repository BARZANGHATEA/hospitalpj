import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { verifyToken } from '@/lib/db';
import type { AuthRequest, JWTPayload, UserRole } from './types';

export async function withAuth(
  request: NextRequest,
  handler: (req: AuthRequest) => Promise<NextResponse>,
  requiredRoles?: UserRole[]
) {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const payload = verifyToken(token) as JWTPayload;

    if (!payload) {
      return NextResponse.json(
        { success: false, error: 'Invalid token' },
        { status: 401 }
      );
    }

    // Check if token is expired
    if (payload.exp && payload.exp < Date.now() / 1000) {
      return NextResponse.json(
        { success: false, error: 'Token expired' },
        { status: 401 }
      );
    }

    // Check required roles
    if (requiredRoles && !requiredRoles.includes(payload.role)) {
      return NextResponse.json(
        { success: false, error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    // Add user to request
    const authRequest = request as AuthRequest;
    authRequest.user = {
      id: payload.userId,
      role: payload.role,
      username: '', // These will be populated from the database in the handler if needed
      email: '',
      is_approved: true,
    };

    return handler(authRequest);
  } catch (error) {
    console.error('Auth middleware error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Helper function to protect API routes
export function protectRoute(
  handler: (req: AuthRequest, context?: any) => Promise<NextResponse>,
  requiredRoles?: UserRole[]
) {
  return (request: NextRequest, context?: any) =>
    withAuth(request, (req: AuthRequest) => handler(req, context), requiredRoles);
}

// Helper function to validate request body
export function validateBody<T>(
  body: any,
  requiredFields: (keyof T)[],
  optionalFields?: (keyof T)[]
): { isValid: boolean; error?: string } {
  try {
    // Check if body exists and is an object
    if (!body || typeof body !== 'object') {
      return { isValid: false, error: 'Invalid request body' };
    }

    // Check required fields
    for (const field of requiredFields) {
      if (!(field in body)) {
        return {
          isValid: false,
          error: `Missing required field: ${String(field)}`,
        };
      }
    }

    // Check that all fields in body are either required or optional
    const allowedFields = [...requiredFields, ...(optionalFields || [])];
    const extraFields = Object.keys(body).filter(
      (key) => !allowedFields.includes(key as keyof T)
    );

    if (extraFields.length > 0) {
      return {
        isValid: false,
        error: `Unknown fields: ${extraFields.join(', ')}`,
      };
    }

    return { isValid: true };
  } catch (error) {
    console.error('Validation error:', error);
    return { isValid: false, error: 'Validation error' };
  }
}

// Helper function to handle API errors
export function handleError(error: unknown) {
  console.error('API error:', error);
  
  if (error instanceof Error) {
    // Handle known error types
    if (error.message.includes('duplicate key')) {
      return NextResponse.json(
        { success: false, error: 'Resource already exists' },
        { status: 409 }
      );
    }
    if (error.message.includes('not found')) {
      return NextResponse.json(
        { success: false, error: 'Resource not found' },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 400 }
    );
  }

  // Handle unknown errors
  return NextResponse.json(
    { success: false, error: 'Internal server error' },
    { status: 500 }
  );
}

// Example usage:
/*
import { protectRoute, validateBody } from '@/lib/auth/middleware';
import type { LoginCredentials } from '@/lib/auth/types';

export const POST = protectRoute(async (request: AuthRequest) => {
  try {
    const body = await request.json();
    
    // Validate request body
    const validation = validateBody<LoginCredentials>(
      body,
      ['email', 'password'], // required fields
      [] // optional fields
    );
    
    if (!validation.isValid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      );
    }

    // Your handler logic here
    // Access authenticated user with request.user
    
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return handleError(error);
  }
}, ['admin']); // Required roles
*/
