import { Pool } from 'pg';
import { createHash } from 'crypto';
import jwt from 'jsonwebtoken';

// Database configuration
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: parseInt(process.env.DB_PORT || '5432'),
  ssl: process.env.NODE_ENV === 'production',
});

// Helper function to hash passwords
export const hashPassword = (password: string): string => {
  return createHash('sha256')
    .update(password + process.env.PASSWORD_SALT)
    .digest('hex');
};

// Helper function to verify passwords
export const verifyPassword = (password: string, hash: string): boolean => {
  return hashPassword(password) === hash;
};

// Helper function to generate JWT tokens
export const generateToken = (userId: string, role: string): string => {
  return jwt.sign(
    { userId, role },
    process.env.JWT_SECRET || 'your-secret-key',
    { expiresIn: '24h' }
  );
};

// Helper function to verify JWT tokens
export const verifyToken = (token: string) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
  } catch (error) {
    return null;
  }
};

// Database query helper
export const query = async (text: string, params?: any[]) => {
  const client = await pool.connect();
  try {
    const result = await client.query(text, params);
    return result;
  } finally {
    client.release();
  }
};

// User-related queries
export const createUser = async (
  username: string,
  email: string,
  password: string,
  role: 'admin' | 'doctor' | 'patient'
) => {
  const hashedPassword = hashPassword(password);
  const result = await query(
    'INSERT INTO users (username, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id, username, email, role',
    [username, email, hashedPassword, role]
  );
  return result.rows[0];
};

export const findUserByEmail = async (email: string) => {
  const result = await query(
    'SELECT id, username, email, password_hash, role, is_approved FROM users WHERE email = $1',
    [email]
  );
  return result.rows[0];
};

export const findUserById = async (id: string) => {
  const result = await query(
    'SELECT id, username, email, role, is_approved FROM users WHERE id = $1',
    [id]
  );
  return result.rows[0];
};

// Doctor-related queries
export const createDoctorProfile = async (
  userId: string,
  specialty: string,
  bio: string,
  education: string[],
  certifications: string[],
  experienceYears: number,
  location: string,
  availability: string,
  languages: string[]
) => {
  const result = await query(
    `INSERT INTO doctor_profiles 
     (user_id, specialty, bio, education, certifications, experience_years, location, availability, languages)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [userId, specialty, bio, education, certifications, experienceYears, location, availability, languages]
  );
  return result.rows[0];
};

export const findDoctorProfile = async (userId: string) => {
  const result = await query(
    `SELECT dp.*, u.username, u.email 
     FROM doctor_profiles dp 
     JOIN users u ON dp.user_id = u.id 
     WHERE dp.user_id = $1`,
    [userId]
  );
  return result.rows[0];
};

// Article-related queries
export const createArticle = async (
  title: string,
  content: string,
  excerpt: string,
  authorId: string,
  category: string,
  imageUrl: string,
  readTime: string
) => {
  const result = await query(
    `INSERT INTO articles 
     (title, content, excerpt, author_id, category, image_url, read_time, is_published)
     VALUES ($1, $2, $3, $4, $5, $6, $7, true)
     RETURNING *`,
    [title, content, excerpt, authorId, category, imageUrl, readTime]
  );
  return result.rows[0];
};

export const findArticleById = async (id: string) => {
  const result = await query(
    `SELECT a.*, u.username as author_name
     FROM articles a
     JOIN users u ON a.author_id = u.id
     WHERE a.id = $1 AND a.is_published = true`,
    [id]
  );
  return result.rows[0];
};

// Prescription-related queries
export const createPrescription = async (
  patientId: string,
  doctorId: string,
  symptoms: string,
  diagnosis: string,
  notes: string,
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }>
) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Create prescription
    const prescriptionResult = await client.query(
      `INSERT INTO prescriptions 
       (patient_id, doctor_id, symptoms, diagnosis, notes)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id`,
      [patientId, doctorId, symptoms, diagnosis, notes]
    );
    const prescriptionId = prescriptionResult.rows[0].id;

    // Add medications
    for (const med of medications) {
      await client.query(
        `INSERT INTO prescription_medications
         (prescription_id, name, dosage, frequency, duration)
         VALUES ($1, $2, $3, $4, $5)`,
        [prescriptionId, med.name, med.dosage, med.frequency, med.duration]
      );
    }

    await client.query('COMMIT');
    return prescriptionId;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

export const findPrescriptionById = async (id: string) => {
  const prescription = await query(
    `SELECT p.*, 
            u_patient.username as patient_name,
            u_doctor.username as doctor_name
     FROM prescriptions p
     JOIN users u_patient ON p.patient_id = u_patient.id
     JOIN users u_doctor ON p.doctor_id = u_doctor.id
     WHERE p.id = $1`,
    [id]
  );

  if (prescription.rows[0]) {
    const medications = await query(
      'SELECT * FROM prescription_medications WHERE prescription_id = $1',
      [id]
    );
    return { ...prescription.rows[0], medications: medications.rows };
  }

  return null;
};

export default {
  query,
  createUser,
  findUserByEmail,
  findUserById,
  createDoctorProfile,
  findDoctorProfile,
  createArticle,
  findArticleById,
  createPrescription,
  findPrescriptionById,
};
