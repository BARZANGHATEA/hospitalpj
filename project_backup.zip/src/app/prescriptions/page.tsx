"use client";

import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, FileText, Calendar, Download } from "lucide-react";

// Mock data for prescriptions
const prescriptions = [
  {
    id: "PRE001",
    doctorName: "Dr. Sarah Johnson",
    date: "2024-06-10",
    status: "Active",
    medications: [
      {
        name: "Amoxicillin",
        dosage: "500mg",
        frequency: "3 times daily",
        duration: "7 days",
      },
      {
        name: "Ibuprofen",
        dosage: "400mg",
        frequency: "As needed",
        duration: "5 days",
      },
    ],
    notes: "Take with food. Complete full course of antibiotics.",
  },
  {
    id: "PRE002",
    doctorName: "Dr. Michael Chen",
    date: "2024-06-08",
    status: "Completed",
    medications: [
      {
        name: "Loratadine",
        dosage: "10mg",
        frequency: "Once daily",
        duration: "30 days",
      },
    ],
    notes: "Take in the morning. Avoid alcohol.",
  },
  {
    id: "PRE003",
    doctorName: "Dr. Emily Williams",
    date: "2024-06-05",
    status: "Expired",
    medications: [
      {
        name: "Paracetamol",
        dosage: "500mg",
        frequency: "4 times daily",
        duration: "3 days",
      },
    ],
    notes: "Take as needed for fever or pain.",
  },
];

const statusColors = {
  Active: "text-success",
  Completed: "text-muted-foreground",
  Expired: "text-destructive",
} as const;

export default function PrescriptionsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const filteredPrescriptions = prescriptions.filter((prescription) => {
    const matchesSearch =
      prescription.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prescription.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "All" || prescription.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Hero Section */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              My Prescriptions
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
              View and manage your digital prescriptions
            </p>
          </div>

          {/* Search and Filter */}
          <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search prescriptions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="Expired">Expired</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Prescriptions List */}
          <div className="space-y-6">
            {filteredPrescriptions.map((prescription) => (
              <Card key={prescription.id} className="prescription-card">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xl">
                    Prescription #{prescription.id}
                  </CardTitle>
                  <span className={statusColors[prescription.status as keyof typeof statusColors]}>
                    {prescription.status}
                  </span>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <div className="mb-4">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">Doctor:</span>
                        </div>
                        <p className="mt-1 text-muted-foreground">
                          {prescription.doctorName}
                        </p>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">Date Prescribed:</span>
                        </div>
                        <p className="mt-1 text-muted-foreground">
                          {new Date(prescription.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium">Medications:</h4>
                      <ul className="mt-2 space-y-2">
                        {prescription.medications.map((medication, index) => (
                          <li key={index} className="text-sm text-muted-foreground">
                            <span className="font-medium">{medication.name}</span> -{" "}
                            {medication.dosage}, {medication.frequency} for{" "}
                            {medication.duration}
                          </li>
                        ))}
                      </ul>
                      {prescription.notes && (
                        <div className="mt-4">
                          <h4 className="font-medium">Notes:</h4>
                          <p className="mt-1 text-sm text-muted-foreground">
                            {prescription.notes}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="mt-6 flex justify-end">
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download PDF
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredPrescriptions.length === 0 && (
              <div className="mt-12 text-center">
                <p className="text-lg text-muted-foreground">
                  No prescriptions found matching your criteria.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
