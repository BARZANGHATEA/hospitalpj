"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Clock, Calendar, User, MessageCircle, ThumbsUp, Send, ArrowLeft } from "lucide-react";

interface Comment {
  id: number;
  author: string;
  content: string;
  date: string;
  likes: number;
}

interface Article {
  id: number;
  title: string;
  content: string;
  author: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
  comments: Comment[];
}

// Mock article data
const article: Article = {
  id: 1,
  title: "Understanding Heart Health: A Comprehensive Guide",
  content: `
    <h2>Introduction</h2>
    <p>Heart health is a crucial aspect of overall well-being that affects millions of people worldwide. Understanding how to maintain a healthy heart can significantly reduce the risk of cardiovascular diseases and improve quality of life.</p>

    <h2>Key Factors in Heart Health</h2>
    <p>Several factors contribute to maintaining a healthy heart:</p>
    <ul>
      <li>Regular physical activity</li>
      <li>Balanced diet rich in fruits and vegetables</li>
      <li>Stress management</li>
      <li>Adequate sleep</li>
      <li>Regular medical check-ups</li>
    </ul>

    <h2>The Role of Exercise</h2>
    <p>Exercise is one of the most important factors in maintaining heart health. Regular physical activity helps:</p>
    <ul>
      <li>Strengthen the heart muscle</li>
      <li>Improve circulation</li>
      <li>Control blood pressure</li>
      <li>Manage weight</li>
      <li>Reduce stress</li>
    </ul>

    <h2>Dietary Considerations</h2>
    <p>A heart-healthy diet typically includes:</p>
    <ul>
      <li>Lean proteins</li>
      <li>Whole grains</li>
      <li>Fresh fruits and vegetables</li>
      <li>Healthy fats</li>
      <li>Limited processed foods</li>
    </ul>

    <h2>Conclusion</h2>
    <p>Taking care of your heart doesn't have to be complicated. By making simple lifestyle changes and staying informed about heart health, you can significantly reduce your risk of cardiovascular disease and maintain a healthy heart for years to come.</p>
  `,
  author: "Dr. Sarah Johnson",
  category: "Cardiology",
  date: "2024-06-10",
  readTime: "5 min read",
  image: "/articles/heart-health.jpg",
  comments: [
    {
      id: 1,
      author: "John D.",
      content: "Very informative article! The dietary tips are particularly helpful.",
      date: "2024-06-11",
      likes: 12,
    },
    {
      id: 2,
      author: "Maria R.",
      content: "I appreciate the comprehensive overview of heart health factors. Would love to see more specific exercise recommendations in a future article.",
      date: "2024-06-10",
      likes: 8,
    },
  ],
};

export default function ArticlePage({ params }: { params: { id: string } }) {
  const [newComment, setNewComment] = useState("");
  const { toast } = useToast();

  const handleSubmitComment = () => {
    if (!newComment.trim()) {
      toast({
        title: "Error",
        description: "Please write a comment before submitting.",
        variant: "destructive",
      });
      return;
    }

    // TODO: Integrate with backend
    toast({
      title: "Success",
      description: "Your comment has been submitted.",
    });
    setNewComment("");
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Back Button */}
          <Button variant="ghost" className="mb-6" asChild>
            <Link href="/articles">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Articles
            </Link>
          </Button>

          {/* Article Header */}
          <div className="relative mb-8 h-[400px] w-full overflow-hidden rounded-lg">
            <Image
              src={article.image}
              alt={article.title}
              className="object-cover"
              fill
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-background/20" />
            <div className="absolute bottom-0 left-0 p-8">
              <div className="mb-4 flex items-center gap-4">
                <span className="rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary">
                  {article.category}
                </span>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {article.readTime}
                </div>
              </div>
              <h1 className="text-4xl font-bold text-foreground">{article.title}</h1>
              <div className="mt-4 flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{article.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    {new Date(article.date).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Article Content */}
          <div className="prose prose-lg mx-auto max-w-4xl dark:prose-invert">
            <div dangerouslySetInnerHTML={{ __html: article.content }} />
          </div>

          {/* Comments Section */}
          <div className="mx-auto mt-12 max-w-4xl">
            <Separator className="my-8" />
            <h2 className="mb-6 text-2xl font-bold">Comments</h2>
            
            {/* Comment Form */}
            <Card className="mb-8">
              <CardContent className="pt-6">
                <Textarea
                  placeholder="Share your thoughts..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="mb-4"
                />
                <Button onClick={handleSubmitComment}>
                  <Send className="mr-2 h-4 w-4" />
                  Post Comment
                </Button>
              </CardContent>
            </Card>

            {/* Comments List */}
            <div className="space-y-6">
              {article.comments.map((comment) => (
                <Card key={comment.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{comment.author}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {new Date(comment.date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="mt-4 text-muted-foreground">{comment.content}</p>
                    <div className="mt-4 flex items-center gap-4">
                      <Button variant="ghost" size="sm">
                        <ThumbsUp className="mr-2 h-4 w-4" />
                        {comment.likes}
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Reply
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
