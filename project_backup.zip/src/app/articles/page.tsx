"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Clock, User } from "lucide-react";

interface Article {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
}

// Mock data for articles
const articles: Article[] = [
  {
    id: 1,
    title: "Understanding Heart Health: A Comprehensive Guide",
    excerpt:
      "Learn about the essential factors that contribute to maintaining a healthy heart and preventing cardiovascular diseases.",
    content: "Full article content here...",
    author: "Dr. Sarah Johnson",
    category: "Cardiology",
    date: "2024-06-10",
    readTime: "5 min read",
    image: "/articles/heart-health.jpg",
  },
  {
    id: 2,
    title: "The Importance of Mental Health in Modern Life",
    excerpt:
      "Explore the significance of mental well-being and discover practical strategies for maintaining good mental health.",
    content: "Full article content here...",
    author: "Dr. Michael Chen",
    category: "Mental Health",
    date: "2024-06-08",
    readTime: "7 min read",
    image: "/articles/mental-health.jpg",
  },
  {
    id: 3,
    title: "Nutrition Tips for a Healthy Lifestyle",
    excerpt:
      "Discover evidence-based nutrition advice to help you make informed decisions about your diet and overall health.",
    content: "Full article content here...",
    author: "Dr. Emily Williams",
    category: "Nutrition",
    date: "2024-06-05",
    readTime: "6 min read",
    image: "/articles/nutrition.jpg",
  },
  {
    id: 4,
    title: "Exercise and Physical Therapy: A Guide to Recovery",
    excerpt:
      "Learn about the role of physical therapy in rehabilitation and how exercise can aid in recovery from injuries.",
    content: "Full article content here...",
    author: "Dr. James Martinez",
    category: "Physical Therapy",
    date: "2024-06-03",
    readTime: "8 min read",
    image: "/articles/physical-therapy.jpg",
  },
];

const categories = [
  "All Categories",
  "Cardiology",
  "Mental Health",
  "Nutrition",
  "Physical Therapy",
  "Pediatrics",
  "General Health",
];

export default function ArticlesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");

  const filteredArticles = articles.filter((article) => {
    const matchesSearch =
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "All Categories" ||
      article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Hero Section */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              Health Articles & Resources
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
              Stay informed with the latest medical insights and health tips from our experts
            </p>
          </div>

          {/* Search and Filter */}
          <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select
              value={selectedCategory}
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Articles Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredArticles.map((article) => (
              <Card key={article.id} className="article-card">
                <div className="relative h-48">
                  <Image
                    src={article.image}
                    alt={article.title}
                    className="rounded-t-lg object-cover"
                    fill
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                      {article.category}
                    </span>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      {article.readTime}
                    </div>
                  </div>
                  <CardTitle className="line-clamp-2 mt-2 text-xl">
                    {article.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-3 text-muted-foreground">
                    {article.excerpt}
                  </p>
                  <div className="mt-6 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        {article.author}
                      </span>
                    </div>
                    <Button variant="link" asChild>
                      <Link href={`/articles/${article.id}`}>Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="mt-12 text-center">
              <p className="text-lg text-muted-foreground">
                No articles found matching your criteria.
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
