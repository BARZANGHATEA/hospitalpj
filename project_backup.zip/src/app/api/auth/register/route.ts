import { NextResponse } from 'next/server';
import { createUser, createDoctorProfile } from '@/lib/db';
import { validateBody } from '@/lib/auth/middleware';
import type { RegisterData } from '@/lib/auth/types';

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Validate request body
    const validation = validateBody<RegisterData>(
      body,
      ['username', 'email', 'password', 'role'],
      [
        'specialty',
        'bio',
        'education',
        'certifications',
        'experienceYears',
        'location',
        'availability',
        'languages',
      ]
    );

    if (!validation.isValid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      );
    }

    // Validate password strength
    if (body.password.length < 8) {
      return NextResponse.json(
        { success: false, error: 'Password must be at least 8 characters long' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(body.email)) {
      return NextResponse.json(
        { success: false, error: 'Invalid email format' },
        { status: 400 }
      );
    }

    // Additional validation for doctor registration
    if (body.role === 'doctor') {
      if (!body.specialty) {
        return NextResponse.json(
          { success: false, error: 'Specialty is required for doctors' },
          { status: 400 }
        );
      }
      if (!body.education || !Array.isArray(body.education) || body.education.length === 0) {
        return NextResponse.json(
          { success: false, error: 'Education details are required for doctors' },
          { status: 400 }
        );
      }
      if (!body.experienceYears || body.experienceYears < 0) {
        return NextResponse.json(
          { success: false, error: 'Valid experience years are required for doctors' },
          { status: 400 }
        );
      }
    }

    // Create user
    const user = await createUser(
      body.username,
      body.email,
      body.password,
      body.role
    );

    // If registering as a doctor, create doctor profile
    if (body.role === 'doctor') {
      await createDoctorProfile(
        user.id,
        body.specialty!,
        body.bio || '',
        body.education!,
        body.certifications || [],
        body.experienceYears!,
        body.location || '',
        body.availability || '',
        body.languages || ['English']
      );
    }

    // Return success response
    return NextResponse.json({
      success: true,
      data: {
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
        },
        message: body.role === 'doctor'
          ? 'Registration successful. Your account is pending approval.'
          : 'Registration successful. Please log in.',
      },
    });
  } catch (error: any) {
    console.error('Registration error:', error);

    // Handle duplicate email error
    if (error.code === '23505' && error.constraint === 'users_email_key') {
      return NextResponse.json(
        { success: false, error: 'Email already registered' },
        { status: 409 }
      );
    }

    // Handle duplicate username error
    if (error.code === '23505' && error.constraint === 'users_username_key') {
      return NextResponse.json(
        { success: false, error: 'Username already taken' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
