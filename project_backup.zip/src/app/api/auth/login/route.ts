import { NextResponse } from 'next/server';
import { findUserByEmail, verifyPassword, generateToken } from '@/lib/db';
import { validateBody } from '@/lib/auth/middleware';
import type { LoginCredentials } from '@/lib/auth/types';

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Validate request body
    const validation = validateBody<LoginCredentials>(
      body,
      ['email', 'password']
    );

    if (!validation.isValid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      );
    }

    // Find user by email
    const user = await findUserByEmail(body.email);
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    // Verify password
    if (!verifyPassword(body.password, user.password_hash)) {
      return NextResponse.json(
        { success: false, error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    // Check if user is approved (for doctors)
    if (user.role === 'doctor' && !user.is_approved) {
      return NextResponse.json(
        {
          success: false,
          error: 'Your account is pending approval. We will notify you once approved.',
        },
        { status: 403 }
      );
    }

    // Generate JWT token
    const token = generateToken(user.id, user.role);

    // Return user data and token
    return NextResponse.json({
      success: true,
      data: {
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
        },
        token,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
