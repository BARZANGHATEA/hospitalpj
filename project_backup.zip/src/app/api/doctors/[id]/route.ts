import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';

// GET /api/doctors/[id] - Get doctor profile and reviews
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Get doctor profile
    const profileResult = await query(
      `SELECT 
        dp.*,
        u.username,
        u.email
      FROM doctor_profiles dp
      JOIN users u ON dp.user_id = u.id
      WHERE dp.id = $1 AND u.is_approved = true`,
      [params.id]
    );

    if (profileResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Doctor not found' },
        { status: 404 }
      );
    }

    const doctor = profileResult.rows[0];

    // Get doctor's reviews
    const reviewsResult = await query(
      `SELECT 
        c.*,
        u.username as reviewer_name
      FROM comments c
      JOIN users u ON c.user_id = u.id
      WHERE c.doctor_id = $1
      ORDER BY c.created_at DESC`,
      [params.id]
    );

    return NextResponse.json({
      success: true,
      data: {
        ...doctor,
        reviews: reviewsResult.rows,
      },
    });
  } catch (error) {
    console.error('Error fetching doctor profile:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/doctors/[id]/reviews - Add a review for a doctor (protected route)
export const POST = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { content, rating } = body;

    // Validate content
    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: 'Review content is required' },
        { status: 400 }
      );
    }

    // Validate rating
    if (!rating || typeof rating !== 'number' || rating < 1 || rating > 5) {
      return NextResponse.json(
        { success: false, error: 'Rating must be between 1 and 5' },
        { status: 400 }
      );
    }

    // Check if doctor exists
    const doctorResult = await query(
      'SELECT * FROM doctor_profiles WHERE id = $1',
      [context.params.id]
    );

    if (doctorResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Doctor not found' },
        { status: 404 }
      );
    }

    // Check if user has already reviewed this doctor
    const existingReview = await query(
      'SELECT * FROM comments WHERE user_id = $1 AND doctor_id = $2',
      [user.id, context.params.id]
    );

    if (existingReview.rows.length > 0) {
      return NextResponse.json(
        { success: false, error: 'You have already reviewed this doctor' },
        { status: 409 }
      );
    }

    // Start a transaction to add review and update doctor's rating
    const client = await query('BEGIN');
    try {
      // Add review
      const reviewResult = await query(
        `INSERT INTO comments (user_id, doctor_id, content)
         VALUES ($1, $2, $3)
         RETURNING *`,
        [user.id, context.params.id, content]
      );

      // Update doctor's rating and review count
      await query(
        `UPDATE doctor_profiles
         SET rating = (
           SELECT AVG(CAST(content->>'rating' as INTEGER))
           FROM comments
           WHERE doctor_id = $1
         ),
         review_count = review_count + 1
         WHERE id = $1`,
        [context.params.id]
      );

      await query('COMMIT');

      // Get updated doctor profile
      const updatedDoctor = await query(
        'SELECT * FROM doctor_profiles WHERE id = $1',
        [context.params.id]
      );

      return NextResponse.json({
        success: true,
        data: {
          review: reviewResult.rows[0],
          doctor: updatedDoctor.rows[0],
        },
        message: 'Review added successfully',
      });
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error adding review:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['patient']); // Only patients can add reviews

// PATCH /api/doctors/[id] - Update doctor profile (protected route)
export const PATCH = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Check if the doctor profile belongs to the authenticated user
    const profileResult = await query(
      'SELECT * FROM doctor_profiles WHERE id = $1',
      [context.params.id]
    );

    if (profileResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Doctor profile not found' },
        { status: 404 }
      );
    }

    if (profileResult.rows[0].user_id !== user.id) {
      return NextResponse.json(
        { success: false, error: 'You can only update your own profile' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      specialty,
      bio,
      education,
      certifications,
      experienceYears,
      location,
      availability,
      languages,
    } = body;

    // Update profile
    const result = await query(
      `UPDATE doctor_profiles
       SET specialty = COALESCE($1, specialty),
           bio = COALESCE($2, bio),
           education = COALESCE($3, education),
           certifications = COALESCE($4, certifications),
           experience_years = COALESCE($5, experience_years),
           location = COALESCE($6, location),
           availability = COALESCE($7, availability),
           languages = COALESCE($8, languages),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $9
       RETURNING *`,
      [
        specialty,
        bio,
        education,
        certifications,
        experienceYears,
        location,
        availability,
        languages,
        context.params.id,
      ]
    );

    return NextResponse.json({
      success: true,
      data: result.rows[0],
      message: 'Profile updated successfully',
    });
  } catch (error) {
    console.error('Error updating doctor profile:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor']); // Only doctors can update their profiles
