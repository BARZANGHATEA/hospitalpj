import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';

// GET /api/doctors - Get all doctors
export const GET = async (request: Request) => {
  try {
    const { searchParams } = new URL(request.url);
    const specialty = searchParams.get('specialty');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = (page - 1) * limit;

    // Build the query
    let queryText = `
      SELECT 
        dp.*,
        u.username,
        u.email,
        COUNT(*) OVER() as total_count
      FROM doctor_profiles dp
      JOIN users u ON dp.user_id = u.id
      WHERE u.role = 'doctor' AND u.is_approved = true
    `;
    const queryParams: any[] = [];

    // Add specialty filter
    if (specialty && specialty !== 'All Specialties') {
      queryText += ` AND dp.specialty = $${queryParams.length + 1}`;
      queryParams.push(specialty);
    }

    // Add search filter
    if (search) {
      queryText += ` AND (
        u.username ILIKE $${queryParams.length + 1} OR
        dp.specialty ILIKE $${queryParams.length + 1} OR
        dp.bio ILIKE $${queryParams.length + 1}
      )`;
      queryParams.push(`%${search}%`);
    }

    // Add pagination
    queryText += ` ORDER BY dp.rating DESC, dp.review_count DESC
                  LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}`;
    queryParams.push(limit, offset);

    const result = await query(queryText, queryParams);

    // Calculate total pages
    const totalCount = result.rows[0]?.total_count ? parseInt(result.rows[0].total_count) : 0;
    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      success: true,
      data: {
        doctors: result.rows.map(({ total_count, ...doctor }) => doctor),
        pagination: {
          currentPage: page,
          totalPages,
          totalCount,
          hasMore: page < totalPages,
        },
      },
    });
  } catch (error) {
    console.error('Error fetching doctors:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
};

// POST /api/doctors - Create or update doctor profile (protected route)
export const POST = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      specialty,
      bio,
      education,
      certifications,
      experienceYears,
      location,
      availability,
      languages,
    } = body;

    // Check if doctor profile exists
    const existingProfile = await query(
      'SELECT * FROM doctor_profiles WHERE user_id = $1',
      [user.id]
    );

    if (existingProfile.rows.length > 0) {
      // Update existing profile
      const result = await query(
        `UPDATE doctor_profiles
         SET specialty = $1,
             bio = $2,
             education = $3,
             certifications = $4,
             experience_years = $5,
             location = $6,
             availability = $7,
             languages = $8,
             updated_at = CURRENT_TIMESTAMP
         WHERE user_id = $9
         RETURNING *`,
        [
          specialty,
          bio,
          education,
          certifications,
          experienceYears,
          location,
          availability,
          languages,
          user.id,
        ]
      );

      return NextResponse.json({
        success: true,
        data: result.rows[0],
        message: 'Doctor profile updated successfully',
      });
    } else {
      // Create new profile
      const result = await query(
        `INSERT INTO doctor_profiles
         (user_id, specialty, bio, education, certifications, experience_years,
          location, availability, languages)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         RETURNING *`,
        [
          user.id,
          specialty,
          bio,
          education,
          certifications,
          experienceYears,
          location,
          availability,
          languages,
        ]
      );

      return NextResponse.json({
        success: true,
        data: result.rows[0],
        message: 'Doctor profile created successfully',
      });
    }
  } catch (error) {
    console.error('Error managing doctor profile:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor']); // Only doctors can create/update profiles
