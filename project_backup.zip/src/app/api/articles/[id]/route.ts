import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';

// GET /api/articles/[id] - Get a specific article with comments
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Get article with author details
    const articleResult = await query(
      `SELECT 
        a.*,
        u.username as author_name
       FROM articles a
       JOIN users u ON a.author_id = u.id
       WHERE a.id = $1 AND a.is_published = true`,
      [params.id]
    );

    if (articleResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Article not found' },
        { status: 404 }
      );
    }

    // Get comments with user details
    const commentsResult = await query(
      `SELECT 
        c.*,
        u.username as commenter_name
       FROM comments c
       JOIN users u ON c.user_id = u.id
       WHERE c.article_id = $1
       ORDER BY c.created_at DESC`,
      [params.id]
    );

    return NextResponse.json({
      success: true,
      data: {
        ...articleResult.rows[0],
        comments: commentsResult.rows,
      },
    });
  } catch (error) {
    console.error('Error fetching article:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/articles/[id]/comments - Add a comment to an article
export const POST = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { content } = body;

    // Validate content
    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: 'Comment content is required' },
        { status: 400 }
      );
    }

    // Check if article exists
    const articleResult = await query(
      'SELECT * FROM articles WHERE id = $1 AND is_published = true',
      [context.params.id]
    );

    if (articleResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Article not found' },
        { status: 404 }
      );
    }

    // Add comment
    const result = await query(
      `INSERT INTO comments (user_id, article_id, content)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [user.id, context.params.id, content]
    );

    // Get commenter name
    const commenterResult = await query(
      'SELECT username FROM users WHERE id = $1',
      [user.id]
    );

    return NextResponse.json({
      success: true,
      data: {
        ...result.rows[0],
        commenter_name: commenterResult.rows[0].username,
      },
      message: 'Comment added successfully',
    });
  } catch (error) {
    console.error('Error adding comment:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'patient']); // Both doctors and patients can comment

// PATCH /api/articles/[id] - Update an article (author only)
export const PATCH = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Check if article exists and user is the author
    const articleResult = await query(
      'SELECT * FROM articles WHERE id = $1',
      [context.params.id]
    );

    if (articleResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Article not found' },
        { status: 404 }
      );
    }

    if (articleResult.rows[0].author_id !== user.id) {
      return NextResponse.json(
        { success: false, error: 'You can only update your own articles' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, content, excerpt, category, imageUrl, readTime } = body;

    // Update article
    const result = await query(
      `UPDATE articles
       SET title = COALESCE($1, title),
           content = COALESCE($2, content),
           excerpt = COALESCE($3, excerpt),
           category = COALESCE($4, category),
           image_url = COALESCE($5, image_url),
           read_time = COALESCE($6, read_time),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $7
       RETURNING *`,
      [title, content, excerpt, category, imageUrl, readTime, context.params.id]
    );

    return NextResponse.json({
      success: true,
      data: result.rows[0],
      message: 'Article updated successfully',
    });
  } catch (error) {
    console.error('Error updating article:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor']); // Only doctors can update articles

// DELETE /api/articles/[id] - Delete an article (admin or author only)
export const DELETE = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Check if article exists
    const articleResult = await query(
      'SELECT * FROM articles WHERE id = $1',
      [context.params.id]
    );

    if (articleResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Article not found' },
        { status: 404 }
      );
    }

    // Check if user is admin or author
    if (user.role !== 'admin' && articleResult.rows[0].author_id !== user.id) {
      return NextResponse.json(
        { success: false, error: 'You can only delete your own articles' },
        { status: 403 }
      );
    }

    // Delete article (cascade will handle comments)
    await query('DELETE FROM articles WHERE id = $1', [context.params.id]);

    return NextResponse.json({
      success: true,
      message: 'Article deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting article:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'admin']); // Only doctors (authors) and admins can delete articles
