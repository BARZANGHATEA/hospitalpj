import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';

interface ArticleBody {
  title: string;
  content: string;
  excerpt: string;
  category: string;
  imageUrl: string;
  readTime: string;
}

// GET /api/articles - Get all published articles
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = (page - 1) * limit;

    // Build query
    let queryText = `
      SELECT 
        a.*,
        u.username as author_name,
        COUNT(*) OVER() as total_count
      FROM articles a
      JOIN users u ON a.author_id = u.id
      WHERE a.is_published = true
    `;
    const queryParams: any[] = [];

    // Add category filter
    if (category && category !== 'All Categories') {
      queryText += ` AND a.category = $${queryParams.length + 1}`;
      queryParams.push(category);
    }

    // Add search filter
    if (search) {
      queryText += ` AND (
        a.title ILIKE $${queryParams.length + 1} OR
        a.excerpt ILIKE $${queryParams.length + 1} OR
        a.content ILIKE $${queryParams.length + 1}
      )`;
      queryParams.push(`%${search}%`);
    }

    // Add pagination
    queryText += ` ORDER BY a.published_at DESC
                  LIMIT $${queryParams.length + 1} OFFSET $${
      queryParams.length + 2
    }`;
    queryParams.push(limit, offset);

    const result = await query(queryText, queryParams);

    // Calculate pagination info
    const totalCount = result.rows[0]?.total_count
      ? parseInt(result.rows[0].total_count)
      : 0;
    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      success: true,
      data: {
        articles: result.rows.map(({ total_count, ...article }) => article),
        pagination: {
          currentPage: page,
          totalPages,
          totalCount,
          hasMore: page < totalPages,
        },
      },
    });
  } catch (error) {
    console.error('Error fetching articles:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/articles - Create a new article (doctors only)
export const POST = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json() as ArticleBody;
    const { title, content, excerpt, category, imageUrl, readTime } = body;

    // Validate required fields
    if (!title || !content || !excerpt || !category) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Create article
    const result = await query(
      `INSERT INTO articles 
       (title, content, excerpt, author_id, category, image_url, read_time, is_published)
       VALUES ($1, $2, $3, $4, $5, $6, $7, true)
       RETURNING *`,
      [title, content, excerpt, user.id, category, imageUrl, readTime]
    );

    // Get author name
    const authorResult = await query(
      'SELECT username FROM users WHERE id = $1',
      [user.id]
    );

    return NextResponse.json({
      success: true,
      data: {
        ...result.rows[0],
        author_name: authorResult.rows[0].username,
      },
      message: 'Article published successfully',
    });
  } catch (error) {
    console.error('Error creating article:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor']); // Only doctors can create articles

// GET /api/articles/categories - Get all article categories
export async function GET_CATEGORIES() {
  try {
    const result = await query(
      'SELECT DISTINCT category FROM articles WHERE is_published = true'
    );

    return NextResponse.json({
      success: true,
      data: result.rows.map((row) => row.category),
    });
  } catch (error) {
    console.error('Error fetching categories:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
