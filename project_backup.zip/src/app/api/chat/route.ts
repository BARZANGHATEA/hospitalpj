import { NextResponse } from 'next/server';
import OpenAI from 'openai';
import type { ChatCompletionMessageParam } from 'openai/resources/chat';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// System message to set the AI's role and context
const SYSTEM_MESSAGE: ChatCompletionMessageParam = {
  role: 'system',
  content: `You are an AI medical assistant. Your role is to:
- Provide general health information and guidance
- Help users understand medical terms and conditions
- Suggest when users should seek professional medical help
- Remind users that you are not a replacement for professional medical advice
- Never make definitive diagnoses or prescribe medications
- Be clear about limitations and encourage consulting healthcare professionals`,
};

interface Message {
  role: 'user' | 'ai';
  content: string;
}

interface ChatMessage {
  id: string;
  user_id: string;
  content: string;
  sender: 'user' | 'ai';
  conversation_id: string;
  created_at: string;
}

// GET /api/chat/history - Get chat history for a user
export const GET = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get('conversationId');

    let queryText = `
      SELECT *
      FROM chat_messages
      WHERE user_id = $1
    `;
    const queryParams: any[] = [user.id];

    if (conversationId) {
      queryText += ' AND conversation_id = $2';
      queryParams.push(conversationId);
    }

    queryText += ' ORDER BY created_at ASC';

    const result = await query(queryText, queryParams);

    return NextResponse.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error('Error fetching chat history:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'patient']);

// POST /api/chat - Send a message and get AI response
export const POST = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { message, conversationId } = body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: 'Message is required' },
        { status: 400 }
      );
    }

    // Start transaction
    await query('BEGIN');

    try {
      // Save user message
      const userMessageResult = await query(
        `INSERT INTO chat_messages (user_id, content, sender, conversation_id)
         VALUES ($1, $2, 'user', $3)
         RETURNING *`,
        [user.id, message, conversationId || user.id]
      );

      // Get conversation history (limited to last 10 messages for context)
      const historyResult = await query(
        `SELECT content, sender
         FROM chat_messages
         WHERE conversation_id = $1
         ORDER BY created_at DESC
         LIMIT 10`,
        [conversationId || user.id]
      );

      // Format messages for OpenAI
      const messages: ChatCompletionMessageParam[] = [
        SYSTEM_MESSAGE,
        ...historyResult.rows.reverse().map((msg): ChatCompletionMessageParam => ({
          role: msg.sender === 'user' ? 'user' : 'assistant',
          content: msg.content,
        })),
      ];

      try {
        // Get AI response
        const completion = await openai.chat.completions.create({
          model: 'gpt-4',
          messages,
          temperature: 0.7,
          max_tokens: 500,
        });

        const aiResponse = completion.choices[0]?.message?.content || 
          'I apologize, but I am unable to provide a response at this time.';

        // Save AI response
        const aiMessageResult = await query(
          `INSERT INTO chat_messages (user_id, content, sender, conversation_id)
           VALUES ($1, $2, 'ai', $3)
           RETURNING *`,
          [user.id, aiResponse, conversationId || user.id]
        );

        await query('COMMIT');

        return NextResponse.json({
          success: true,
          data: {
            userMessage: userMessageResult.rows[0],
            aiMessage: aiMessageResult.rows[0],
            conversationId: conversationId || user.id,
          },
        });
      } catch (error: any) {
        await query('ROLLBACK');
        
        // Handle OpenAI specific errors
        if (error.status === 429) {
          return NextResponse.json(
            { success: false, error: 'Rate limit exceeded. Please try again later.' },
            { status: 429 }
          );
        }

        throw error;
      }
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error processing chat message:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'patient']);

// DELETE /api/chat - Delete chat history
export const DELETE = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get('conversationId');

    let queryText = 'DELETE FROM chat_messages WHERE user_id = $1';
    const queryParams: any[] = [user.id];

    if (conversationId) {
      queryText += ' AND conversation_id = $2';
      queryParams.push(conversationId);
    }

    await query(queryText, queryParams);

    return NextResponse.json({
      success: true,
      message: conversationId
        ? 'Conversation deleted successfully'
        : 'Chat history deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting chat history:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'patient']);
