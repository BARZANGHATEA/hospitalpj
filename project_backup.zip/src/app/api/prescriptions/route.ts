import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';
import type { QueryResult } from 'pg';

interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
}

interface PrescriptionBody {
  patientId: string;
  symptoms: string;
  diagnosis: string;
  notes?: string;
  medications: Medication[];
  validUntil?: string;
}

// GET /api/prescriptions - Get prescriptions (filtered by user role)
export const GET = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = (page - 1) * limit;

    // Build query based on user role
    let queryText = `
      SELECT 
        p.*,
        u_patient.username as patient_name,
        u_doctor.username as doctor_name,
        COUNT(*) OVER() as total_count
      FROM prescriptions p
      JOIN users u_patient ON p.patient_id = u_patient.id
      JOIN users u_doctor ON p.doctor_id = u_doctor.id
    `;
    const queryParams: any[] = [];

    // Filter by role
    if (user.role === 'patient') {
      queryText += ' WHERE p.patient_id = $1';
      queryParams.push(user.id);
    } else if (user.role === 'doctor') {
      queryText += ' WHERE p.doctor_id = $1';
      queryParams.push(user.id);
    }

    // Add status filter if provided
    if (status && status !== 'all') {
      queryText += ` AND p.status = $${queryParams.length + 1}`;
      queryParams.push(status);
    }

    // Add pagination
    queryText += ` ORDER BY p.created_at DESC
                  LIMIT $${queryParams.length + 1} OFFSET $${
      queryParams.length + 2
    }`;
    queryParams.push(limit, offset);

    const prescriptionsResult = await query(queryText, queryParams);

    // Get medications for each prescription
    const prescriptions = await Promise.all(
      prescriptionsResult.rows.map(async ({ total_count, ...prescription }) => {
        const medicationsResult = await query(
          'SELECT * FROM prescription_medications WHERE prescription_id = $1',
          [prescription.id]
        );
        return {
          ...prescription,
          medications: medicationsResult.rows,
        };
      })
    );

    // Calculate pagination info
    const totalCount = prescriptionsResult.rows[0]?.total_count
      ? parseInt(prescriptionsResult.rows[0].total_count)
      : 0;
    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      success: true,
      data: {
        prescriptions,
        pagination: {
          currentPage: page,
          totalPages,
          totalCount,
          hasMore: page < totalPages,
        },
      },
    });
  } catch (error) {
    console.error('Error fetching prescriptions:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'patient']); // Only doctors and patients can view prescriptions

// POST /api/prescriptions - Create a new prescription (doctors only)
export const POST = protectRoute(async (request: AuthRequest) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json() as PrescriptionBody;
    const {
      patientId,
      symptoms,
      diagnosis,
      notes,
      medications,
      validUntil,
    } = body;

    // Validate required fields
    if (!patientId || !symptoms || !diagnosis || !medications) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Validate medications array
    if (!Array.isArray(medications) || medications.length === 0) {
      return NextResponse.json(
        { success: false, error: 'At least one medication is required' },
        { status: 400 }
      );
    }

    // Validate each medication
    for (const med of medications) {
      if (!med.name || !med.dosage || !med.frequency || !med.duration) {
        return NextResponse.json(
          { success: false, error: 'Invalid medication data' },
          { status: 400 }
        );
      }
    }

    // Start transaction
    await query('BEGIN');
    try {
      // Create prescription
      const prescriptionResult = await query(
        `INSERT INTO prescriptions 
         (patient_id, doctor_id, symptoms, diagnosis, notes, valid_until)
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING *`,
        [patientId, user.id, symptoms, diagnosis, notes, validUntil]
      );

      const prescriptionId = prescriptionResult.rows[0].id;

      // Add medications
      for (const med of medications) {
        await query(
          `INSERT INTO prescription_medications
           (prescription_id, name, dosage, frequency, duration)
           VALUES ($1, $2, $3, $4, $5)`,
          [prescriptionId, med.name, med.dosage, med.frequency, med.duration]
        );
      }

      await query('COMMIT');

      // Get complete prescription with medications
      const result = await query(
        `SELECT 
          p.*,
          u_patient.username as patient_name,
          u_doctor.username as doctor_name
         FROM prescriptions p
         JOIN users u_patient ON p.patient_id = u_patient.id
         JOIN users u_doctor ON p.doctor_id = u_doctor.id
         WHERE p.id = $1`,
        [prescriptionId]
      );

      const medicationsResult = await query(
        'SELECT * FROM prescription_medications WHERE prescription_id = $1',
        [prescriptionId]
      );

      return NextResponse.json({
        success: true,
        data: {
          ...result.rows[0],
          medications: medicationsResult.rows,
        },
        message: 'Prescription created successfully',
      });
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error creating prescription:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor']); // Only doctors can create prescriptions
