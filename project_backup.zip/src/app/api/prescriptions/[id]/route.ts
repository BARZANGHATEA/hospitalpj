import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { protectRoute } from '@/lib/auth/middleware';
import type { AuthRequest } from '@/lib/auth/types';

// GET /api/prescriptions/[id] - Get a specific prescription
export const GET = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get prescription with user details
    const prescriptionResult = await query(
      `SELECT 
        p.*,
        u_patient.username as patient_name,
        u_doctor.username as doctor_name
       FROM prescriptions p
       JOIN users u_patient ON p.patient_id = u_patient.id
       JOIN users u_doctor ON p.doctor_id = u_doctor.id
       WHERE p.id = $1`,
      [context.params.id]
    );

    if (prescriptionResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Prescription not found' },
        { status: 404 }
      );
    }

    const prescription = prescriptionResult.rows[0];

    // Check if user has access to this prescription
    if (
      user.role === 'patient' && prescription.patient_id !== user.id ||
      user.role === 'doctor' && prescription.doctor_id !== user.id
    ) {
      return NextResponse.json(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    // Get medications
    const medicationsResult = await query(
      'SELECT * FROM prescription_medications WHERE prescription_id = $1',
      [context.params.id]
    );

    return NextResponse.json({
      success: true,
      data: {
        ...prescription,
        medications: medicationsResult.rows,
      },
    });
  } catch (error) {
    console.error('Error fetching prescription:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor', 'patient']);

// PATCH /api/prescriptions/[id] - Update prescription status
export const PATCH = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    const { user } = request;
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { status } = body;

    // Validate status
    if (!status || !['active', 'completed', 'expired'].includes(status)) {
      return NextResponse.json(
        { success: false, error: 'Invalid status' },
        { status: 400 }
      );
    }

    // Get prescription
    const prescriptionResult = await query(
      'SELECT * FROM prescriptions WHERE id = $1',
      [context.params.id]
    );

    if (prescriptionResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Prescription not found' },
        { status: 404 }
      );
    }

    const prescription = prescriptionResult.rows[0];

    // Only the prescribing doctor can update the status
    if (prescription.doctor_id !== user.id) {
      return NextResponse.json(
        { success: false, error: 'Only the prescribing doctor can update the status' },
        { status: 403 }
      );
    }

    // Update status
    const result = await query(
      `UPDATE prescriptions
       SET status = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING *`,
      [status, context.params.id]
    );

    return NextResponse.json({
      success: true,
      data: result.rows[0],
      message: 'Prescription status updated successfully',
    });
  } catch (error) {
    console.error('Error updating prescription:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['doctor']);

// DELETE /api/prescriptions/[id] - Delete a prescription (admin only)
export const DELETE = protectRoute(async (request: AuthRequest, context: { params: { id: string } }) => {
  try {
    // Check if prescription exists
    const prescriptionResult = await query(
      'SELECT * FROM prescriptions WHERE id = $1',
      [context.params.id]
    );

    if (prescriptionResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Prescription not found' },
        { status: 404 }
      );
    }

    // Delete prescription (cascade will handle medications)
    await query('DELETE FROM prescriptions WHERE id = $1', [context.params.id]);

    return NextResponse.json({
      success: true,
      message: 'Prescription deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting prescription:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}, ['admin']); // Only admins can delete prescriptions
