import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Brain,
  Users,
  Shield,
  Clock,
  Award,
  HeartPulse,
  Stethoscope,
  MessageCircle,
} from "lucide-react";

const features = [
  {
    name: "AI-Powered Assistance",
    description:
      "Get instant medical guidance through our advanced AI system that understands your symptoms and provides initial assessments.",
    icon: Brain,
  },
  {
    name: "Expert Doctors",
    description:
      "Connect with verified healthcare professionals specializing in various medical fields.",
    icon: Stethoscope,
  },
  {
    name: "24/7 Availability",
    description:
      "Access healthcare services and consultations around the clock, whenever you need them.",
    icon: Clock,
  },
  {
    name: "Secure Platform",
    description:
      "Your health data is protected with enterprise-grade security and encryption.",
    icon: Shield,
  },
  {
    name: "Digital Prescriptions",
    description:
      "Receive and manage your prescriptions securely online, with easy access and tracking.",
    icon: HeartPulse,
  },
  {
    name: "Health Community",
    description:
      "Join a community of health-conscious individuals and share experiences.",
    icon: Users,
  },
  {
    name: "Quality Care",
    description:
      "Experience healthcare that meets the highest standards of medical excellence.",
    icon: Award,
  },
  {
    name: "Real-time Chat",
    description:
      "Communicate with healthcare providers through our secure messaging system.",
    icon: MessageCircle,
  },
];

const stats = [
  { id: 1, name: "Active Users", value: "50,000+" },
  { id: 2, name: "Verified Doctors", value: "500+" },
  { id: 3, name: "Consultations", value: "100,000+" },
  { id: 4, name: "Success Rate", value: "98%" },
];

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <div className="relative isolate overflow-hidden bg-background px-6 py-24 sm:py-32 lg:px-8">
          <div className="absolute inset-0 -z-10 opacity-30">
            <div className="hero-pattern absolute inset-x-0 top-0 h-[1000px] w-full" />
          </div>
          <div className="mx-auto max-w-7xl">
            <div className="mx-auto max-w-2xl lg:mx-0">
              <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">
                About Our Platform
              </h1>
              <p className="mt-6 text-lg leading-8 text-muted-foreground">
                We are revolutionizing healthcare delivery through technology,
                making quality medical care accessible to everyone, anywhere,
                anytime.
              </p>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-primary/5 py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:max-w-none">
              <div className="grid grid-cols-1 gap-8 text-center lg:grid-cols-4">
                {stats.map((stat) => (
                  <Card key={stat.id}>
                    <CardContent className="pt-6">
                      <div className="mt-2 flex flex-col items-center gap-1">
                        <span className="text-3xl font-bold tracking-tight">
                          {stat.value}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {stat.name}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Everything you need for modern healthcare
              </h2>
              <p className="mt-6 text-lg leading-8 text-muted-foreground">
                Our platform combines cutting-edge technology with medical expertise
                to provide comprehensive healthcare solutions.
              </p>
            </div>
            <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
              <div className="grid grid-cols-1 gap-x-8 gap-y-16 lg:grid-cols-4">
                {features.map((feature) => (
                  <Card key={feature.name} className="relative pl-16">
                    <CardContent className="pt-6">
                      <div className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                        <feature.icon
                          className="h-6 w-6 text-white"
                          aria-hidden="true"
                        />
                      </div>
                      <h3 className="font-semibold">{feature.name}</h3>
                      <p className="mt-2 text-sm text-muted-foreground">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="relative isolate overflow-hidden bg-primary/5">
          <div className="px-6 py-24 sm:px-6 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Ready to experience the future of healthcare?
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-muted-foreground">
                Join thousands of satisfied patients who have already transformed
                their healthcare experience with our platform.
              </p>
              <div className="mt-10 flex items-center justify-center gap-x-6">
                <Button size="lg" asChild>
                  <Link href="/register">Get Started</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/doctors">Meet Our Doctors</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
