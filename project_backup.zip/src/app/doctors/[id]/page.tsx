"use client";

import { useState } from "react";
import Image from "next/image";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Star, MapPin, Clock, Calendar, Send } from "lucide-react";

interface Review {
  id: number;
  patientName: string;
  rating: number;
  date: string;
  comment: string;
}

interface DoctorProfile {
  id: number;
  name: string;
  specialty: string;
  image: string;
  rating: number;
  reviewCount: number;
  experience: string;
  education: string[];
  certifications: string[];
  bio: string;
  location: string;
  availability: string;
  languages: string[];
  patientReviews: Review[];
}

// Mock data for doctor profile
const doctorProfile: DoctorProfile = {
  id: 1,
  name: "Dr. Sarah Johnson",
  specialty: "Cardiology",
  image: "/doctors/sarah-johnson.jpg",
  rating: 4.8,
  reviewCount: 124,
  experience: "15+ years",
  education: [
    "MD - Stanford University School of Medicine",
    "Residency - Mayo Clinic",
    "Fellowship - Cleveland Clinic",
  ],
  certifications: [
    "American Board of Internal Medicine",
    "American College of Cardiology",
  ],
  bio: "Dr. Sarah Johnson is a board-certified cardiologist with over 15 years of experience in treating complex cardiovascular conditions. She specializes in preventive cardiology, heart failure management, and cardiac imaging.",
  location: "123 Medical Center Drive, Suite 200",
  availability: "Mon-Fri: 9:00 AM - 5:00 PM",
  languages: ["English", "Spanish"],
  patientReviews: [
    {
      id: 1,
      patientName: "John D.",
      rating: 5,
      date: "2024-06-01",
      comment:
        "Dr. Johnson is an excellent doctor who takes time to listen and explain everything thoroughly. Highly recommended!",
    },
    {
      id: 2,
      patientName: "Maria R.",
      rating: 4,
      date: "2024-05-28",
      comment:
        "Very knowledgeable and professional. The wait time was a bit long but the care was worth it.",
    },
    {
      id: 3,
      patientName: "David M.",
      rating: 5,
      date: "2024-05-25",
      comment:
        "Outstanding experience. Dr. Johnson's expertise and bedside manner are exceptional.",
    },
  ],
};

export default function DoctorProfilePage({ params }: { params: { id: string } }) {
  const [newReview, setNewReview] = useState("");
  const { toast } = useToast();

  const handleSubmitReview = () => {
    if (!newReview.trim()) {
      toast({
        title: "Error",
        description: "Please write a review before submitting.",
        variant: "destructive",
      });
      return;
    }

    // TODO: Integrate with backend
    toast({
      title: "Success",
      description: "Your review has been submitted.",
    });
    setNewReview("");
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Profile Header */}
          <div className="mb-8 grid gap-8 md:grid-cols-3">
            <Card className="md:col-span-1">
              <CardContent className="pt-6">
                <div className="relative mx-auto aspect-square w-48 overflow-hidden rounded-full">
                  <Image
                    src={doctorProfile.image}
                    alt={doctorProfile.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="mt-4 text-center">
                  <h1 className="text-2xl font-bold">{doctorProfile.name}</h1>
                  <p className="text-muted-foreground">{doctorProfile.specialty}</p>
                  <div className="mt-2 flex items-center justify-center gap-2">
                    <Star className="h-5 w-5 fill-warning text-warning" />
                    <span className="font-medium">{doctorProfile.rating}</span>
                    <span className="text-sm text-muted-foreground">
                      ({doctorProfile.reviewCount} reviews)
                    </span>
                  </div>
                </div>
                <div className="mt-6 space-y-4">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm">{doctorProfile.location}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm">{doctorProfile.availability}</span>
                  </div>
                </div>
                <Button className="mt-6 w-full">Book Appointment</Button>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardContent className="pt-6">
                <Tabs defaultValue="about">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="about">About</TabsTrigger>
                    <TabsTrigger value="education">Education</TabsTrigger>
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                  </TabsList>
                  <TabsContent value="about" className="mt-6">
                    <h3 className="mb-4 text-lg font-semibold">Biography</h3>
                    <p className="text-muted-foreground">{doctorProfile.bio}</p>
                    <h3 className="mb-2 mt-6 text-lg font-semibold">
                      Languages Spoken
                    </h3>
                    <div className="flex gap-2">
                      {doctorProfile.languages.map((language) => (
                        <span
                          key={language}
                          className="rounded-full bg-secondary px-3 py-1 text-sm"
                        >
                          {language}
                        </span>
                      ))}
                    </div>
                  </TabsContent>
                  <TabsContent value="education" className="mt-6">
                    <h3 className="mb-4 text-lg font-semibold">Education</h3>
                    <ul className="space-y-4">
                      {doctorProfile.education.map((edu, index) => (
                        <li
                          key={index}
                          className="flex items-start gap-3 text-muted-foreground"
                        >
                          <Calendar className="mt-1 h-5 w-5" />
                          <span>{edu}</span>
                        </li>
                      ))}
                    </ul>
                    <h3 className="mb-4 mt-6 text-lg font-semibold">
                      Certifications
                    </h3>
                    <ul className="space-y-4">
                      {doctorProfile.certifications.map((cert, index) => (
                        <li
                          key={index}
                          className="flex items-start gap-3 text-muted-foreground"
                        >
                          <Star className="mt-1 h-5 w-5" />
                          <span>{cert}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                  <TabsContent value="reviews" className="mt-6">
                    <div className="space-y-6">
                      {doctorProfile.patientReviews.map((review) => (
                        <Card key={review.id}>
                          <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <span className="font-medium">
                                  {review.patientName}
                                </span>
                                <div className="mt-1 flex items-center gap-2">
                                  {Array.from({ length: review.rating }).map(
                                    (_, i) => (
                                      <Star
                                        key={i}
                                        className="h-4 w-4 fill-warning text-warning"
                                      />
                                    )
                                  )}
                                </div>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {new Date(review.date).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="mt-4 text-muted-foreground">
                              {review.comment}
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    <div className="mt-8">
                      <h3 className="mb-4 text-lg font-semibold">
                        Write a Review
                      </h3>
                      <Textarea
                        placeholder="Share your experience with Dr. Johnson..."
                        value={newReview}
                        onChange={(e) => setNewReview(e.target.value)}
                        className="mb-4"
                      />
                      <Button onClick={handleSubmitReview}>
                        <Send className="mr-2 h-4 w-4" />
                        Submit Review
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
