# HealthAI - Medical Consultation Platform

A modern medical consultation platform built with Next.js, PostgreSQL, and OpenAI integration.

## Features

- User authentication (Admin, Doctor, Patient roles)
- Doctor profiles and search
- Medical article management
- Prescription management
- AI-powered medical chat assistance
- Real-time consultations

## Prerequisites

- Node.js (v18 or later)
- PostgreSQL (v14 or later)
- OpenAI API key

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd healthai
```

2. Install dependencies:
```bash
npm install --legacy-peer-deps
```

3. Create a PostgreSQL database:
```sql
CREATE DATABASE healthai_db;
```

4. Configure environment variables:
Copy `.env.example` to `.env` and update the values:
```bash
# Database Configuration
DB_USER=your_db_user
DB_HOST=localhost
DB_NAME=healthai_db
DB_PASSWORD=your_db_password
DB_PORT=5432

# Authentication
JWT_SECRET=your_jwt_secret_key
PASSWORD_SALT=your_password_salt

# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key

# Environment
NODE_ENV=development
```

5. Initialize the database:
```bash
npm run init-db
```

This will create the database schema and populate it with sample data, including:
- Admin user: admin@healthai.com / admin123
- Doctor user: doctor@healthai.com / doctor123
- Patient user: patient@healthai.com / patient123

6. Start the development server:
```bash
npm run dev
```

The application will be available at http://localhost:3000

## API Routes

### Authentication
- POST /api/auth/login - User login
- POST /api/auth/register - User registration

### Doctors
- GET /api/doctors - List all doctors
- GET /api/doctors/:id - Get doctor profile
- POST /api/doctors - Create/update doctor profile
- POST /api/doctors/:id/reviews - Add doctor review
- PATCH /api/doctors/:id - Update doctor profile

### Articles
- GET /api/articles - List all articles
- GET /api/articles/:id - Get article with comments
- POST /api/articles - Create new article
- POST /api/articles/:id/comments - Add article comment
- PATCH /api/articles/:id - Update article
- DELETE /api/articles/:id - Delete article

### Prescriptions
- GET /api/prescriptions - List user's prescriptions
- GET /api/prescriptions/:id - Get prescription details
- POST /api/prescriptions - Create new prescription
- PATCH /api/prescriptions/:id - Update prescription status
- DELETE /api/prescriptions/:id - Delete prescription

### Chat
- GET /api/chat/history - Get chat history
- POST /api/chat - Send message and get AI response
- DELETE /api/chat - Delete chat history

## Project Structure

```
healthai/
├── src/
│   ├── app/              # Next.js app router
│   │   ├── api/         # API routes
│   │   └── ...         # Page components
│   ├── components/      # React components
│   │   ├── layout/     # Layout components
│   │   └── ui/         # UI components
│   └── lib/            # Utilities and helpers
│       ├── auth/       # Authentication
│       └── db/         # Database
├── scripts/            # Setup and utility scripts
└── public/            # Static assets
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
