import { Pool } from 'pg';
import { readFileSync } from 'fs';
import { join } from 'path';
import { config } from 'dotenv';
import { createHash } from 'crypto';

// Load environment variables
config();

// Helper function to hash passwords
const hashPassword = (password: string): string => {
  return createHash('sha256')
    .update(password + process.env.PASSWORD_SALT)
    .digest('hex');
};

async function initializeDatabase() {
  const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: parseInt(process.env.DB_PORT || '5432'),
  });

  try {
    // Read schema file
    const schemaPath = join(process.cwd(), 'src', 'lib', 'db', 'schema.sql');
    const schema = readFileSync(schemaPath, 'utf8');

    // Execute schema
    await pool.query(schema);
    console.log('Database schema initialized successfully');

    // Create admin user
    const adminPassword = hashPassword('admin123'); // Change this in production
    await pool.query(
      `INSERT INTO users (username, email, password_hash, role, is_approved)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (email) DO NOTHING`,
      ['admin', 'admin@healthai.com', adminPassword, 'admin', true]
    );
    console.log('Admin user created successfully');

    // Create sample doctor
    const doctorPassword = hashPassword('doctor123'); // Change this in production
    const doctorResult = await pool.query(
      `INSERT INTO users (username, email, password_hash, role, is_approved)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id`,
      ['Dr. Smith', 'doctor@healthai.com', doctorPassword, 'doctor', true]
    );

    await pool.query(
      `INSERT INTO doctor_profiles 
       (user_id, specialty, bio, education, certifications, experience_years,
        location, availability, languages)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [
        doctorResult.rows[0].id,
        'Cardiology',
        'Experienced cardiologist specializing in preventive care and heart health management. Dedicated to providing comprehensive cardiac care and patient education.',
        ['MD from Harvard Medical School', 'Residency at Mayo Clinic'],
        ['Board Certified in Cardiology', 'Advanced Cardiac Life Support'],
        15,
        'New York, NY',
        'Mon-Fri, 9AM-5PM',
        ['English', 'Spanish'],
      ]
    );
    console.log('Sample doctor created successfully');

    // Create sample patient
    const patientPassword = hashPassword('patient123'); // Change this in production
    await pool.query(
      `INSERT INTO users (username, email, password_hash, role, is_approved)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (email) DO NOTHING`,
      ['John Doe', 'patient@healthai.com', patientPassword, 'patient', true]
    );
    console.log('Sample patient created successfully');

    // Create sample article
    await pool.query(
      `INSERT INTO articles 
       (title, content, excerpt, author_id, category, image_url, read_time, is_published)
       VALUES ($1, $2, $3, $4, $5, $6, $7, true)`,
      [
        'Understanding Heart Health',
        `Heart health is crucial for overall well-being. This comprehensive guide covers:

1. Basics of Heart Function
Your heart is a remarkable organ that works tirelessly to pump blood throughout your body. Understanding how it works is the first step to maintaining its health.

2. Risk Factors
Several factors can affect heart health:
- High blood pressure
- High cholesterol
- Smoking
- Obesity
- Physical inactivity
- Diabetes
- Family history

3. Prevention Strategies
Maintaining heart health involves:
- Regular exercise (at least 30 minutes daily)
- Balanced diet rich in fruits and vegetables
- Limited salt and saturated fat intake
- Stress management
- Regular check-ups

4. Warning Signs
Know these heart attack warning signs:
- Chest pain or pressure
- Shortness of breath
- Pain in arms, back, or jaw
- Cold sweat
- Unusual fatigue
- Nausea

5. Lifestyle Changes
Simple changes can make a big difference:
- Walk more
- Choose stairs over elevator
- Eat more whole grains
- Reduce processed foods
- Get adequate sleep
- Quit smoking

Remember: Prevention is always better than cure. Regular check-ups and a healthy lifestyle are your best defense against heart disease.`,
        'Learn about heart health basics, risk factors, and prevention strategies in this comprehensive guide.',
        doctorResult.rows[0].id,
        'Cardiology',
        'https://example.com/heart-health.jpg',
        '5 min read'
      ]
    );
    console.log('Sample article created successfully');

    console.log('\nDatabase initialized successfully with sample data!');
    console.log('\nLogin credentials:');
    console.log('Admin: admin@healthai.com / admin123');
    console.log('Doctor: doctor@healthai.com / doctor123');
    console.log('Patient: patient@healthai.com / patient123');

  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

initializeDatabase().catch(console.error);
