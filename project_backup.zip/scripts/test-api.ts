import { config } from 'dotenv';
import fetch from 'node-fetch';

// Load environment variables
config();

const BASE_URL = 'http://localhost:3000/api';

interface LoginResponse {
  success: boolean;
  data?: {
    user: {
      id: string;
      username: string;
      email: string;
      role: string;
    };
    token: string;
  };
  error?: string;
}

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

class ApiError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = 'ApiError';
  }
}

async function testAPI() {
  try {
    console.log('🏥 Testing HealthAI API endpoints...\n');

    // Test authentication
    console.log('1. Testing Authentication:');
    
    // Login as admin
    console.log('- Testing admin login...');
    const adminLoginData = await fetchJson<LoginResponse>(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@healthai.com',
        password: 'admin123',
      }),
    });
    
    if (!adminLoginData.success) {
      throw new ApiError(`Admin login failed: ${adminLoginData.error}`);
    }
    console.log('✅ Admin login successful');
    const adminToken = adminLoginData.data!.token;

    // Login as doctor
    console.log('- Testing doctor login...');
    const doctorLoginData = await fetchJson<LoginResponse>(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'doctor@healthai.com',
        password: 'doctor123',
      }),
    });
    
    if (!doctorLoginData.success) {
      throw new ApiError(`Doctor login failed: ${doctorLoginData.error}`);
    }
    console.log('✅ Doctor login successful');
    const doctorToken = doctorLoginData.data!.token;

    // Test doctors endpoints
    console.log('\n2. Testing Doctors API:');
    
    // Get all doctors
    console.log('- Testing get all doctors...');
    const doctorsData = await fetchJson<ApiResponse>(`${BASE_URL}/doctors`);
    
    if (!doctorsData.success) {
      throw new ApiError(`Get doctors failed: ${doctorsData.error}`);
    }
    console.log('✅ Get doctors successful');

    // Get doctor profile
    const doctorId = doctorLoginData.data!.user.id;
    console.log('- Testing get doctor profile...');
    const doctorData = await fetchJson<ApiResponse>(`${BASE_URL}/doctors/${doctorId}`);
    
    if (!doctorData.success) {
      throw new ApiError(`Get doctor profile failed: ${doctorData.error}`);
    }
    console.log('✅ Get doctor profile successful');

    // Test articles endpoints
    console.log('\n3. Testing Articles API:');
    
    // Get all articles
    console.log('- Testing get all articles...');
    const articlesData = await fetchJson<ApiResponse>(`${BASE_URL}/articles`);
    
    if (!articlesData.success) {
      throw new ApiError(`Get articles failed: ${articlesData.error}`);
    }
    console.log('✅ Get articles successful');

    // Create article as doctor
    console.log('- Testing create article...');
    const createArticleData = await fetchJson<ApiResponse>(`${BASE_URL}/articles`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${doctorToken}`,
      },
      body: JSON.stringify({
        title: 'Test Article',
        content: 'This is a test article content.',
        excerpt: 'Test article excerpt',
        category: 'General Health',
        imageUrl: 'https://example.com/test.jpg',
        readTime: '2 min read',
      }),
    });
    
    if (!createArticleData.success) {
      throw new ApiError(`Create article failed: ${createArticleData.error}`);
    }
    console.log('✅ Create article successful');

    // Test chat endpoints
    console.log('\n4. Testing Chat API:');
    
    // Send chat message
    console.log('- Testing send message...');
    const chatData = await fetchJson<ApiResponse>(`${BASE_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${doctorToken}`,
      },
      body: JSON.stringify({
        message: 'What are common symptoms of the flu?',
      }),
    });
    
    if (!chatData.success) {
      throw new ApiError(`Send message failed: ${chatData.error}`);
    }
    console.log('✅ Send message successful');

    console.log('\n🎉 All tests passed successfully!');

  } catch (error) {
    if (error instanceof ApiError) {
      console.error('\n❌ Test failed:', error.message);
      if (error.status) {
        console.error('Status:', error.status);
      }
    } else {
      console.error('\n❌ Unexpected error:', error instanceof Error ? error.message : 'Unknown error');
    }
    process.exit(1);
  }
}

// Add test script to package.json
testAPI().catch((error) => {
  console.error('Fatal error:', error instanceof Error ? error.message : 'Unknown error');
  process.exit(1);
});
